
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dsm-2
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Eleitores eleit = new Eleitores();
        
        int op;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite uma opção: \n 1 - Inserir quantidade de Votos" + "\n 2 - Calcular Total de Eleitores" + "\n 3 - Calcular Percentual de Votos" + "\n 4 - Mostrar Valores" + "\n 0 - Sair"));
            switch(op){
                case 1:
                    eleit.inserirQtdVotos();
                break;
                case 2:
                    eleit.calcularTotalEleitores();
                break; 
                case 3:
                    eleit.calcularPercentualVotos();
                break;
                case 4:
                    eleit.mostrarPercentualVotos();
                break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Você decidiu sair.");
                break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                break;
            }
            
        }while(op != 0);
        
    }
    
}
