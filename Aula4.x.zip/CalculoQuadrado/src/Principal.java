
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dsm-2
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Quadrado quad = new Quadrado();
        
         int op;
        double a, b;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("Digite uma opção: \n 1 - Calcular Área" + "\n 2 - Calcular Perímetro" + "\n 3 - Mostrar Valores" + "\n 0 - Sair"));
            
            switch(op){
                case 1:
                    a = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do lado A: "));
                    quad.calcularArea(a);
                break;
                case 2:
                    a = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do lado A: "));
                    quad.calcularPerimetro(a);
                break; 
                case 3:
                    quad.mostrarValores();
                break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Você decidiu sair.");
                break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!");
                break;
            }
            
        }while(op != 0);
        
    }
    
}
